# 前言
我工作用的Mac Pro是256GB ssd硬盘。开发iOS久了，经常提示磁盘空间不够，其中最大原因是来自Xcode®

可以打开 ~/Library/Developer/Xcode/DerivedData 看看，这里存放了Xcode编译构建过的所有项目工程数据。

> 将陈腐失效的缓存数据及时清理掉，你的ssd硬盘可用空间就多起来了。


# 目录

下面是一些开发过程中容易积累缓存的目录，欢迎大家pr补充

```
~/Library/Developer/Xcode/DerivedData
~/Library/Caches
```


